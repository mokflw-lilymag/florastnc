require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');
const puppeteer = require('puppeteer');
const ptp = require('pdf-to-printer');
const fs = require('fs');
const path = require('path');
const http = require('http');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY;
const BRANCH_ID = process.env.BRANCH_ID;

if (!SUPABASE_URL || !SUPABASE_KEY || !BRANCH_ID) {
  console.error("❌ [.env] SUPABASE_URL, SUPABASE_SERVICE_KEY, BRANCH_ID를 모두 입력해주세요.");
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// 1. 윈도우 설치된 프린터 목록을 ERP(Supabase)에 동기화
async function syncPrinters() {
  try {
    const printers = await ptp.getPrinters();
    const printerNames = printers.map(p => typeof p === 'string' ? p : (p.name || p.deviceId));
    console.log("🖨️ [시스템] 설치된 프린터 목록:", printerNames);

    const { data: branch } = await supabase
      .from('branches')
      .select('name')
      .eq('id', BRANCH_ID)
      .single();

    if (!branch) {
      console.error("❌ 지점 정보를 찾을 수 없습니다. BRANCH_ID를 확인해주세요.");
      return;
    }

    const settingsId = `branch_settings_${branch.name}`;
    const { data: settingsRow } = await supabase
      .from('system_settings')
      .select('data')
      .eq('id', settingsId)
      .single();

    let settingsData = settingsRow?.data || {};
    if (!settingsData.general) settingsData.general = {};
    settingsData.general.installedPrinters = printerNames;

    await supabase
      .from('system_settings')
      .upsert({ id: settingsId, data: settingsData, updated_at: new Date().toISOString() });

    console.log(`✅ [시스템] 프린터 목록 ERP 동기화 완료 (${branch.name})`);
  } catch (err) {
    console.error("❌ 프린터 동기화 오류:", err);
  }
}

// 2. 주문 데이터를 HTML 템플릿으로 변환 (영수증 디자인)
function generateHtmlReceipt(job) {
  const { job_type, payload } = job;
  const { orderer, items, summary, pickupInfo, deliveryInfo, message, request } = payload;

  const dateStr = new Date().toLocaleString('ko-KR');
  const title = job_type === 'pickup_memo' ? '픽업 예약 메모' :
                job_type === 'delivery_shop' ? '배송 주문서(매장용)' : '배송 인수증(기사용)';

  const itemsHtml = items.map(item => `
    <tr>
      <td style="text-align: left;">${item.name}</td>
      <td style="text-align: center;">${item.quantity}</td>
      <td style="text-align: right;">${item.price.toLocaleString()}</td>
    </tr>
  `).join('');

  let infoHtml = '';
  if (job_type === 'pickup_memo' && pickupInfo) {
    infoHtml = `
      <p><b>픽업일시:</b> ${pickupInfo.date} ${pickupInfo.time}</p>
      <p><b>수령인:</b> ${pickupInfo.pickerName} (${pickupInfo.pickerContact})</p>
    `;
  } else if ((job_type === 'delivery_shop' || job_type === 'delivery_driver') && deliveryInfo) {
    infoHtml = `
      <p><b>배송일시:</b> ${deliveryInfo.date} ${deliveryInfo.time}</p>
      <p><b>수령인:</b> ${deliveryInfo.recipientName} (${deliveryInfo.recipientContact})</p>
      <p><b>배송지:</b> ${deliveryInfo.address}</p>
    `;
  }

  const messageHtml = message?.content ? `
    <div style="margin-top: 10px; border-top: 1px dashed #000; padding-top: 10px;">
      <p><b>메시지(${message.type}):</b></p>
      <p style="white-space: pre-wrap; margin: 5px 0;">${message.content}</p>
      ${message.sender ? `<p>보내는분: ${message.sender}</p>` : ''}
    </div>
  ` : '';

  return `
    <html>
      <head>
        <meta charset="utf-8">
        <style>
          @page { margin: 0; }
          body { 
            font-family: 'Malgun Gothic', sans-serif; 
            width: 72mm; /* POS standard 80mm paper */
            margin: 0 auto; 
            padding: 10px; 
            font-size: 12px;
            color: #000;
          }
          h2 { text-align: center; margin: 0 0 10px 0; font-size: 18px; }
          .divider { border-bottom: 1px dashed #000; margin: 10px 0; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
          th, td { padding: 4px 0; font-size: 12px; }
          th { border-bottom: 1px solid #000; text-align: left; }
          .right { text-align: right; }
          .total { font-weight: bold; font-size: 14px; }
        </style>
      </head>
      <body>
        <h2>${title}</h2>
        <p style="text-align: center;">${dateStr}</p>
        <div class="divider"></div>
        <p><b>주문자:</b> ${orderer.name} (${orderer.contact})</p>
        ${infoHtml}
        <div class="divider"></div>
        <table>
          <thead>
            <tr><th>상품명</th><th style="text-align:center;">수량</th><th class="right">단가</th></tr>
          </thead>
          <tbody>
            ${itemsHtml}
          </tbody>
        </table>
        <div class="divider"></div>
        <p class="right">주문금액: ${summary.subtotal.toLocaleString()}원</p>
        <p class="right">배송비: ${summary.deliveryFee.toLocaleString()}원</p>
        <p class="right total">총 결제금액: ${summary.total.toLocaleString()}원</p>
        ${request ? `<div class="divider"></div><p><b>요청사항:</b> ${request}</p>` : ''}
        ${messageHtml}
        <div class="divider"></div>
        <p style="text-align: center;">- LilyMag Flower -</p>
      </body>
    </html>
  `;
}

// 3. 메인 프로세스
async function start() {
  console.log("🚀 LilyMag Receipt Bridge 실행 중...");
  await syncPrinters();

  let browser;
  try {
    browser = await puppeteer.launch({ headless: 'new' });
  } catch (err) {
    console.error("❌ Puppeteer 실행 오류:", err);
    return;
  }

  // 실시간 구독 시작
  supabase
    .channel('public:print_jobs')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'print_jobs', filter: `branch_id=eq.${BRANCH_ID}` }, async (payload) => {
      const job = payload.new;
      console.log(`\n📥 새 인쇄 작업 수신: [${job.job_type}] (ID: ${job.id})`);

      try {
        // ERP 설정에서 타겟 프린터 이름 가져오기
        const { data: branch } = await supabase.from('branches').select('name').eq('id', BRANCH_ID).single();
        const { data: settingsRow } = await supabase.from('system_settings').select('data').eq('id', `branch_settings_${branch.name}`).single();
        
        const settings = settingsRow?.data?.general || {};
        const printerName = job.printer_type === 'label' ? settings.labelPrinterName : settings.printerName;

        if (!printerName) {
          console.error("❌ 대상 프린터가 설정되지 않았습니다.");
          await supabase.from('print_jobs').update({ status: 'failed' }).eq('id', job.id);
          return;
        }

        // HTML -> PDF
        const html = generateHtmlReceipt(job);
        const page = await browser.newPage();
        await page.setContent(html);
        
        // 용지 너비 80mm, 높이는 내용에 맞게 자동(임시로 A4 비율을 주지만 ptp에서 내용 크기만큼 프린트됨)
        const pdfBuffer = await page.pdf({ 
            width: '80mm', 
            // 높이는 넉넉하게 설정. 긴 영수증 대응. 
            // 실제 POS 프린터는 내용까지만 출력 후 자릅니다.
            height: '297mm', 
            printBackground: true 
        });
        await page.close();

        const tempPdfPath = path.join(__dirname, `temp_receipt_${job.id}.pdf`);
        fs.writeFileSync(tempPdfPath, pdfBuffer);

        // Windows 인쇄 실행
        console.log(`🖨️ 프린터 [${printerName}] 로 인쇄를 요청합니다...`);
        await ptp.print(tempPdfPath, { printer: printerName });
        
        // 완료 처리
        fs.unlinkSync(tempPdfPath);
        await supabase.from('print_jobs').update({ status: 'printed' }).eq('id', job.id);
        console.log(`✅ 인쇄 완료!`);

      } catch (err) {
        console.error("❌ 인쇄 중 오류 발생:", err);
        await supabase.from('print_jobs').update({ status: 'failed' }).eq('id', job.id);
      }
    })
    .subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        console.log("📡 클라우드 인쇄 대기열(print_jobs) 감시를 시작합니다.");
      }
    });

  // 4. ERP와의 통신을 위한 상태 확인용 HTTP 서버 실행 (포트 8003)
  const server = http.createServer((req, res) => {
    // CORS 처리
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    if (req.url === '/') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'ok', message: 'Print POS Bridge is running' }));
    } else {
      res.writeHead(404);
      res.end();
    }
  });

  server.listen(8003, () => {
    console.log("🟢 [상태 확인] 브릿지 하트비트 서버가 포트 8003에서 실행 중입니다. (ERP PPon 연동)");
  });
}

start();
